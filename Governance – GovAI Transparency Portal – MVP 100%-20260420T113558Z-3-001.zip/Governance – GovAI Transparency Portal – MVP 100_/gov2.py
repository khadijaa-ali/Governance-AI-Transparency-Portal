import streamlit as st
import pandas as pd
import plotly.express as px
from sklearn.ensemble import IsolationForest
import numpy as np
import re 

cnic_df = pd.read_csv(r"C:\Users\Dell\Desktop\Python\streamlit\cnic_dataset.csv")
bill_df = pd.read_csv(r"C:\Users\Dell\Desktop\Python\streamlit\bill_dataset.csv")
gov_df = pd.read_csv(r"C:\Users\Dell\Desktop\Python\gov_Dataset.csv")

st.sidebar.title("Navigation")
menu = st.sidebar.radio("Go to", ["Chatbot", "Dashboard", "Anomaly Detection"])

# chatbot
if menu == "Chatbot":
    st.title("Citizen Service Chatbot")

    lang = st.radio("Select Language / زبان منتخب کریں", ["English", "اردو"])

    def validate_cnic(cnic):
        pattern = r"^\d{5}-?\d{7}-?\d{1}$"  
        return re.match(pattern, cnic) is not None

    if lang == "English":
        st.header("Welcome. Please select a service")
        service = st.selectbox("Choose a service", ["Utility Bill Inquiry", "CNIC Verification"])
    
        if service == "Utility Bill Inquiry":
            ref = st.text_input("Enter your Reference Number")
            if st.button("Check Bill"):
                record = bill_df[bill_df["Reference_No"] == ref]
                if not record.empty:
                    st.success(f"CNIC: {record.iloc[0]['CNIC']}, Bill: {record.iloc[0]['Bill_Amount']} PKR, Due: {record.iloc[0]['Due_Date']}, Status: {record.iloc[0]['Status']}")
                else:
                    st.error("Reference number not found")
    
        if service == "CNIC Verification":
            cnic = st.text_input("Enter your CNIC")
            if st.button("Verify CNIC"):
                if validate_cnic(cnic):
                    record = cnic_df[cnic_df["CNIC"] == cnic]
                    if not record.empty:
                        st.success(f"Name: {record.iloc[0]['Name']}, DOB: {record.iloc[0]['DOB']}, Status: {record.iloc[0]['Status']}")
                    else:
                        st.error("CNIC not found in records")
                else:
                    st.error("Invalid CNIC format. Please enter 13 digits only.")

    elif lang == "اردو":
        st.header("خوش آمدید۔ براہ کرم سروس منتخب کریں")
        service = st.selectbox("سروس منتخب کریں", ["بل انکوائری", "شناختی کارڈ ویریفکیشن"])
    
        if service == "بل انکوائری":
            ref = st.text_input("اپنا ریفرنس نمبر درج کریں")
            if st.button("بل چیک کریں"):
                record = bill_df[bill_df["Reference_No"] == ref]
                if not record.empty:
                    st.success(f"شناختی کارڈ: {record.iloc[0]['CNIC']}, بل: {record.iloc[0]['Bill_Amount']} روپے, آخری تاریخ: {record.iloc[0]['Due_Date']}, حیثیت: {record.iloc[0]['Status']}")
                else:
                    st.error("ریفرنس نمبر نہیں ملا")
    
        if service == "شناختی کارڈ ویریفکیشن":
            cnic = st.text_input("اپنا شناختی کارڈ نمبر درج کریں")
            if st.button("ویریفائی کریں"):
                if validate_cnic(cnic):
                    record = cnic_df[cnic_df["CNIC"] == cnic]
                    if not record.empty:
                        st.success(f"نام: {record.iloc[0]['Name']}, تاریخ پیدائش: {record.iloc[0]['DOB']}, حیثیت: {record.iloc[0]['Status']}")
                    else:
                        st.error("شناختی کارڈ نہیں ملا")
                else:
                    st.error("غلط شناختی کارڈ نمبر۔ براہ کرم 13 ہندسوں کا نمبر درج کریں")


# dashboard
elif menu == "Dashboard":
    st.title("Government Budget Visualization Dashboard")
    st.sidebar.header("Filters")

    year_filter = st.sidebar.multiselect("Select Year", options=gov_df["Year"].unique(), default=gov_df["Year"].unique())
    dept_filter = st.sidebar.multiselect("Select Department", options=gov_df["Department"].unique(), default=gov_df["Department"].unique())

    df_filtered = gov_df[(gov_df["Year"].isin(year_filter)) & (gov_df["Department"].isin(dept_filter))]

    fig1 = px.bar(df_filtered.groupby("Department")["Amount"].sum().reset_index(),
                  x="Department", y="Amount", color="Department",
                  title="Total Budget Allocation by Department")
    st.plotly_chart(fig1, use_container_width=True)

    fig2 = px.scatter(df_filtered, x="Date", y="Amount",
                      color=df_filtered["is_anomaly"].map({0: "Normal", 1: "Anomaly"}),
                      title="Project Amounts Over Time with Anomalies")
    st.plotly_chart(fig2, use_container_width=True)

    fig3 = px.line(df_filtered.groupby("Year")["Amount"].sum().reset_index(),
                   x="Year", y="Amount", title="Yearly Spending Trend")
    st.plotly_chart(fig3, use_container_width=True)

    fig4 = px.pie(df_filtered, names="Status", title="Project Status Distribution")
    st.plotly_chart(fig4, use_container_width=True)

    anomaly_ratio = df_filtered.groupby("Department")["is_anomaly"].mean().reset_index()
    fig5 = px.bar(anomaly_ratio, x="Department", y="is_anomaly", title="Anomaly Ratio by Department")
    st.plotly_chart(fig5, use_container_width=True)

elif menu == "Anomaly Detection":
    st.title("AI-based Anomaly Detection in Procurement Data")

    # Use Amount column for anomaly detection
    model = IsolationForest(contamination=0.1, random_state=42)
    gov_df["anomaly_pred"] = model.fit_predict(gov_df[["Amount"]])

    gov_df["anomaly_status"] = gov_df["anomaly_pred"].map({1: "Normal", -1: "Anomaly"})

    st.write("Sample of detected anomalies:")
    st.dataframe(gov_df[["Department", "Amount", "Status", "anomaly_status"]].head(15))

    # Visualize anomalies
    fig = px.scatter(gov_df, x="Date", y="Amount",
                     color="anomaly_status",
                     title="Anomaly Detection Results on Procurement Data")
    st.plotly_chart(fig, use_container_width=True)





